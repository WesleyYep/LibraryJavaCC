1. valid
2. valid
3. invalid due to duplicate website
4. invalid due to empty name for bookcollection
5. valid (empty position and title is allowed)
6. valid
7. invalid (author has 2 letter in the initial)
8. invalid (no hours for sem 1)
9. invalid (space in website)
10. valid ("https://" for website)
11. valid (spaces between parts of time)
12. invalid (space between hours and minutes)
13. invalid - library name is empty
14. invalid - extra invalid entry
15. invalid - hours (OPEN)
16. valid
17. invalid - too many END
18. invalid - no RATE
19. invalid - Type = No-time
20. valid - multiple emails and they can contain capital letters
21. invalid email
22. invalid email
23. invalid email
24. invalid email
25. valid
26. valid
27. invalid - out of order START and END